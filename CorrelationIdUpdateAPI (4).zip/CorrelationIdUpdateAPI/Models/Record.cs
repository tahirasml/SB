﻿namespace CorrelationIdUpdateAPI.Models
{
    public class Record
    {
        public int Id { get; set; }
        public string CorrelationId { get; set; }
        public string Status { get; set; }
    }
}
