﻿using CorrelationIdUpdateAPI.Services;
using CorrelationIdUpdateAPI.Cryptography;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.IdentityModel.Tokens;
using System;
using Microsoft.Data.SqlClient;
using System.Text;
using Dapper;

namespace CorrelationIdUpdateAPI
{
    public class Startup
    {
        private readonly IConfiguration _configuration;

        public Startup(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public void ConfigureServices(IServiceCollection services)
        {
            // Add controllers and JSON serialization
            services.AddControllers().AddNewtonsoftJson();

            // Register Record Service
            services.AddSingleton<RecordService>();

            // JWT Authentication
            var key = Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]);
            services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
                .AddJwtBearer(options =>
                {
                    options.TokenValidationParameters = new TokenValidationParameters
                    {
                        ValidateIssuer = true,
                        ValidateAudience = true,
                        ValidateLifetime = true,
                        ValidateIssuerSigningKey = true,
                        ValidIssuer = _configuration["Jwt:Issuer"],
                        ValidAudience = _configuration["Jwt:Audience"],
                        IssuerSigningKey = new SymmetricSecurityKey(key)
                    };
                });

            // **Check Database Connectivity at Startup**
            CheckDatabaseConnectivity();
        }

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseRouting();

            app.UseAuthentication();
            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }

        /// <summary>
        /// Checks database connectivity at application startup.
        /// </summary>
        private void CheckDatabaseConnectivity()
        {
            try
            {
                string encryptedConnectionString = _configuration.GetConnectionString("EncryptedConnection");
                string decryptedConnectionString = ConnectionStringSecurity.Decrypt(encryptedConnectionString);

                using var connection = new SqlConnection(decryptedConnectionString);
                connection.Open(); // Try to open the connection

                // Execute a simple query to verify connection
                var result = connection.QueryFirstOrDefault<string>("SELECT 'Connection Successful' AS Status");
                Console.WriteLine(result ?? "Database connectivity check passed!");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"⚠️ Database connectivity check failed: {ex.Message}");
            }
        }
    }
}
