﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace CorrelationIdUpdateAPI.Cryptography
{
    public class ConnectionStringSecurity
    {
        private static byte[] kKey = Encoding.ASCII.GetBytes("4ksBNfdLJM0Nf43uP1ViLH3D");
        private static byte[] kIV = Encoding.ASCII.GetBytes("init vec");

        public static string Encrypt(string plainText)
        {
            byte[] encryptedBytes = Encrypt(Encoding.UTF8.GetBytes(plainText), kKey);
            return Convert.ToBase64String(encryptedBytes);
        }

        public static string Decrypt(string cipherText)
        {
            return Encoding.UTF8.GetString(Decrypt(Convert.FromBase64String(cipherText), kKey));
        }

        private static byte[] Encrypt(byte[] bytesData, byte[] bytesKey)
        {
            using MemoryStream memoryStream = new MemoryStream();
            using var encryptor = new TripleDESCryptoServiceProvider() { Mode = CipherMode.CBC }.CreateEncryptor(bytesKey, kIV);
            using var cryptoStream = new CryptoStream(memoryStream, encryptor, CryptoStreamMode.Write);
            cryptoStream.Write(bytesData, 0, bytesData.Length);
            cryptoStream.FlushFinalBlock();
            return memoryStream.ToArray();
        }

        private static byte[] Decrypt(byte[] bytesData, byte[] bytesKey)
        {
            using MemoryStream memoryStream = new MemoryStream();
            using var decryptor = new TripleDESCryptoServiceProvider() { Mode = CipherMode.CBC }.CreateDecryptor(bytesKey, kIV);
            using var cryptoStream = new CryptoStream(memoryStream, decryptor, CryptoStreamMode.Write);
            cryptoStream.Write(bytesData, 0, bytesData.Length);
            cryptoStream.FlushFinalBlock();
            return memoryStream.ToArray();
        }
    }
}
