﻿using System.Data.SqlClient;
using System.Threading.Tasks;
using Dapper;
using Microsoft.Extensions.Configuration;
using CorrelationIdUpdateAPI.Cryptography;

namespace CorrelationIdUpdateAPI.Services
{
    public class RecordService
    {
        private readonly string _connectionString;

        public RecordService(IConfiguration configuration)
        {
            _connectionString = ConnectionStringSecurity.Decrypt(configuration["ConnectionStrings:EncryptedConnection"]);
        }

        /// <summary>
        /// Get record by CorrelationId
        /// </summary>
        public async Task<Record> GetRecordByCorrelationIdAsync(string correlationId)
        {
            using var connection = new Microsoft.Data.SqlClient.SqlConnection(_connectionString);
            string query = "SELECT * FROM Records WHERE CorrelationId = @CorrelationId";
            return await connection.QueryFirstOrDefaultAsync<Record>(query, new { CorrelationId = correlationId });
        }

        /// <summary>
        /// Update the status of a record based on CorrelationId
        /// </summary>
        public async Task<bool> UpdateRecordStatusAsync(string correlationId, string status)
        {
            using var connection = new Microsoft.Data.SqlClient.SqlConnection(_connectionString);
            string query = "UPDATE Records SET Status = @Status WHERE CorrelationId = @CorrelationId";
            int rowsAffected = await connection.ExecuteAsync(query, new { CorrelationId = correlationId, Status = status });
            return rowsAffected > 0;
        }
    }

    public class Record
    {
        public string CorrelationId { get; set; }
        public string Status { get; set; }
    }
}
