﻿using CorrelationIdUpdateAPI.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace CorrelationIdUpdateAPI.Controllers
{
    [Authorize] // Requires JWT Authentication
    [ApiController]
    [Route("api/[controller]")]
    public class RecordController : ControllerBase
    {
        private readonly RecordService _recordService;

        public RecordController(RecordService recordService)
        {
            _recordService = recordService;
        }

        /// <summary>
        /// Get record by CorrelationId
        /// </summary>
        [HttpGet("{correlationId}")]
        public async Task<IActionResult> GetRecord(string correlationId)
        {
            var record = await _recordService.GetRecordByCorrelationIdAsync(correlationId);
            if (record == null)
                return NotFound("Record not found.");
            return Ok(record);
        }

        /// <summary>
        /// Update the status of a record based on CorrelationId
        /// </summary>
        [HttpPut("{correlationId}")]
        public async Task<IActionResult> UpdateRecordStatus(string correlationId, [FromBody] string status)
        {
            var updated = await _recordService.UpdateRecordStatusAsync(correlationId, status);
            if (!updated)
                return NotFound("Record not found or update failed.");
            return Ok("Record updated successfully.");
        }
    }
}
